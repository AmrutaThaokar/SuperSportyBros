import { Logincun } from './logincun';

describe('Logincun', () => {
  it('should create an instance', () => {
    expect(new Logincun()).toBeTruthy();
  });
});
