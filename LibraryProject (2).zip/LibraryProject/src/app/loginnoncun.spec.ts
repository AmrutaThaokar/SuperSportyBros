import { Loginnoncun } from './loginnoncun';

describe('Loginnoncun', () => {
  it('should create an instance', () => {
    expect(new Loginnoncun()).toBeTruthy();
  });
});
