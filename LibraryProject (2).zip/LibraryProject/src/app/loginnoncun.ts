export class Loginnoncun {
    

id: number = 0;
username: String = "";
password: String = "";
loginAs: String = "";


}
