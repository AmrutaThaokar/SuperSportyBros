import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-router-links',
  templateUrl: './router-links.component.html',
  styleUrls: ['./router-links.component.scss']
})
export class RouterLinksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
